package com.lxl.servlet.config;

/**
 * Created by xiangleiliu on 2017/5/8.
 */
public class Config {

    public static String Save_Path = "C://img";

}
