package com.lxl.servlet.model;

/**
 * Created by xiangleiliu on 2017/5/25.
 */
public class LabelModel {
    public static final int LABLE_MODEL_TYPE_SHOP = 1;
    public static final int LABLE_MODEL_TYPE_TRADING = 2;


    public int mLabId;
    public String mLabName;
    public String mLabUrl;
    public int mRelationId;//
    public int mType;//����
}
